package com.example;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.io.IOException;
import java.util.List;

public class KBCServlet extends HttpServlet {
    private SessionFactory factory;

    @Override
    public void init() throws ServletException {
       
        factory = new Configuration().configure().buildSessionFactory();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        Session session = factory.openSession();
      
        Transaction transaction = null;

        try {
           
            transaction = session.beginTransaction();

            
            List<Question> questions = session.createQuery("FROM Question", Question.class).getResultList();

           
            System.out.println("Questions List: " + questions);

           
            if (!questions.isEmpty()) {
                Question currentQuestion = questions.get(0);
                request.setAttribute("questions", currentQuestion.getQuestion());
            } else {
                request.setAttribute("question", "No questions available.");
            }

           
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            throw new ServletException(e);
        } finally {
            session.close(); 
        }

       
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    public void destroy() {
        factory.close();
    }
}
