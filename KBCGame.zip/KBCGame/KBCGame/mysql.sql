create database kbc_game;
use kbc_game;
CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    option_a VARCHAR(255),
    option_b VARCHAR(255),
    option_c VARCHAR(255),
    option_d VARCHAR(255),
    answer VARCHAR(255) NOT NULL
);

INSERT INTO questions (question, option_a, option_b, option_c, option_d, answer) VALUES
('What is the capital of India?', 'New Delhi', 'Mumbai', 'Kolkata', 'Chennai', 'New Delhi'),
('Who was the first Prime Minister of India?', 'Mahatma Gandhi', 'Jawaharlal Nehru', 'Subhas Chandra Bose', 'Sardar Vallabhbhai Patel', 'Jawaharlal Nehru'),
('Which is the national animal of India?', 'Lion', 'Elephant', 'Tiger', 'Peacock', 'Tiger'),
('Which Indian city is known as the Silicon Valley of India?', 'Hyderabad', 'Mumbai', 'Bangalore', 'Pune', 'Bangalore'),
('Who is known as the "Missile Man of India"?', 'Vikram Sarabhai', 'APJ Abdul Kalam', 'Homi J. Bhabha', 'Rakesh Sharma', 'APJ Abdul Kalam');
select *from questions;